﻿# Connect to Microsoft Graph
Connect-MgGraph -Scopes "Sites.Read.All", "Files.Read.All", "InformationProtectionPolicy.Read.All"

# Optional: Connect to Security & Compliance Center if needed
# Connect-IPPSSession

# Get all sites (SharePoint/OneDrive)
$sites = Get-MgSite -Top 999

# Prepare results array
$results = @()

foreach ($site in $sites) {
    try {
        # Get all drives (document libraries)
        $drives = Get-MgSiteDrive -SiteId $site.Id

        foreach ($drive in $drives) {
            $items = Get-MgDriveRootChildren -DriveId $drive.Id

            foreach ($item in $items) {
                # Check if item has a sensitivity label and is shared externally
                if ($item.Shared -and $item.SensitivityLabel) {
                    $results += [PSCustomObject]@{
                        SiteName         = $site.Name
                        FileName         = $item.Name
                        SensitivityLabel = $item.SensitivityLabel.LabelId
                        SharedWith       = ($item.Shared.SharedWith | Out-String).Trim()
                        WebUrl           = $item.WebUrl
                    }
                }
            }
        }
    } catch {
        Write-Warning "Error processing site $($site.Name): $_"
    }
}

# Export results
$results | Export-Csv -Path "LabeledContentSharedExternally.csv" -NoTypeInformation
Write-Host "Export complete: LabeledContentSharedExternally.csv"
