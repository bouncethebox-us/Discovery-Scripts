﻿#Variable for SharePoint Online Admin Center URL
$AdminSiteURL="https://capitolpowergroup-admin.sharepoint.com"
$CSVFile = "C:\temp\_onedrives.csv"
  
#Connect to SharePoint Online Admin Center
Connect-SPOService -Url $AdminSiteURL
 
#Get All OneDrive Sites usage details and export to CSV
Get-SPOSite -IncludePersonalSite $true -Limit all -Filter "Url -like '-my.sharepoint.com/personal/'" | Select URL, Owner, StorageQuota, StorageUsageCurrent, LastContentModifiedDate | Export-Csv -Path $CSVFile -NoTypeInformation
