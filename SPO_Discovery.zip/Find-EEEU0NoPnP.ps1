<#
.SYNOPSIS
  Enumerate where "Everyone except external users" (and optionally "Everyone") is granted across
  SharePoint Online sites incl. OneDrive, Teams-connected (GROUP#0), and Private Channel sites (TEAMCHANNEL#0).

.DESCRIPTION
  - Uses Microsoft.Online.SharePoint.PowerShell to enumerate sites (-IncludePersonalSite controls OneDrive).
  - Uses CSOM to inspect Web and List scopes, and optional REST+CSOM to inspect item/folder/file scopes with unique perms.
  - Outputs CSV with scope, site type, URLs, principal, roles, etc.

.PARAMETER AdminUrl
  Your SPO admin center URL, e.g. https://contoso-admin.sharepoint.com

.PARAMETER OutputCsv
  Path of the CSV to create.

.PARAMETER Deep
  Also scan items/folders/files that have unique permissions (slower).

.PARAMETER IncludeEveryone
  Also flag the classic "Everyone" (c:0(.s|true).

.PARAMETER IncludeOneDrive
  Include OneDrive for Business personal sites in tenant enumeration (default: $true).

.PARAMETER Credential
  PSCredential to use for CSOM connections to each site (best if non-MFA or app password).
  If omitted and you need MFA, see the App-only token variant further below.

.PARAMETER SiteUrlFilter
  Optional wildcard/regex filter; only sites whose URL -like this pattern will be scanned (e.g. "*://contoso.sharepoint.com/sites/Finance*").

.EXAMPLE
  .\Find-EEEU-NoPnP.ps1 -AdminUrl "https://contoso-admin.sharepoint.com" -OutputCsv .\EEEU.csv

.EXAMPLE
  .\Find-EEEU-NoPnP.ps1 -AdminUrl "https://contoso-admin.sharepoint.com" -OutputCsv .\EEEU-deep.csv -Deep -IncludeEveryone
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)]
  [string]$AdminUrl,

  [Parameter(Mandatory=$true)]
  [string]$OutputCsv,

  [switch]$Deep,
  [switch]$IncludeEveryone,
  [switch]$IncludeOneDrive = $true,

  [System.Management.Automation.PSCredential]$Credential,

  [string]$SiteUrlFilter
)

#region --- Constants & helpers ---
$EEEUPrefix  = 'c:0-.f|rolemanager|spo-grid-all-users'  # Everyone except external users (tenant GUID may follow)
$EveryoneVal = 'c:0(.s|true'                            # Classic "Everyone"

function Ensure-CSOM {
  # Try to load CSOM from common locations; else pull from NuGet into %TEMP%\CSOM
  $loaded = $false
  $candidateDirs = @(
    "$PSScriptRoot\CSOM",
    "$env:ProgramFiles\Microsoft SharePoint Online Client Components\16.0\ISAPI",
    "$env:LOCALAPPDATA\CSOM",
    "$env:TEMP\CSOM"
  ) | Where-Object { Test-Path $_ }

  foreach ($dir in $candidateDirs) {
    try {
      Add-Type -Path (Join-Path $dir 'Microsoft.SharePoint.Client.dll') -ErrorAction Stop
      Add-Type -Path (Join-Path $dir 'Microsoft.SharePoint.Client.Runtime.dll') -ErrorAction Stop
      $script:CSOMPath = $dir
      $loaded = $true
      break
    } catch {}
  }

  if (-not $loaded) {
    Write-Host "Downloading CSOM assemblies to %TEMP%\CSOM ..."
    $dest = Join-Path $env:TEMP 'CSOM'
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    # Download from NuGet v3 flat container
    $pkg = 'Microsoft.SharePointOnline.CSOM'
    $ver = '16.1.23604.12000'  # known good; adjust if needed
    $nupkgUrl = "https://globalcdn.nuget.org/packages/$($pkg.ToLower()).$ver.nupkg"
    $zipPath  = Join-Path $dest "$pkg.$ver.nupkg"
    Invoke-WebRequest -Uri $nupkgUrl -OutFile $zipPath -UseBasicParsing
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $dest, $true)
    # Look for lib/net45
    $lib = Join-Path $dest 'lib\net45'
    Add-Type -Path (Join-Path $lib 'Microsoft.SharePoint.Client.dll')
    Add-Type -Path (Join-Path $lib 'Microsoft.SharePoint.Client.Runtime.dll')
    $script:CSOMPath = $lib
  }
}

function Connect-Admin {
  if (-not (Get-Module -ListAvailable -Name Microsoft.Online.SharePoint.PowerShell)) {
    throw "Module Microsoft.Online.SharePoint.PowerShell is required. Install-Module Microsoft.Online.SharePoint.PowerShell -Scope AllUsers"
  }
  Import-Module Microsoft.Online.SharePoint.PowerShell -ErrorAction Stop
  Write-Host "Connecting to SPO Admin: $AdminUrl ..."
  Connect-SPOService -Url $AdminUrl
}

function Get-TenantSites {
  param([switch]$IncludeOneDrive)
  $params = @{ Limit='All' }
  if ($IncludeOneDrive) { $params['IncludePersonalSite'] = $true }
  try {
    $sites = Get-SPOSite @params
  } catch {
    throw "Failed to enumerate tenant sites: $($_.Exception.Message)"
  }
  return $sites
}

function New-ClientContext {
  param([string]$Url,[System.Management.Automation.PSCredential]$Credential)
  $ctx = New-Object Microsoft.SharePoint.Client.ClientContext($Url)
  if ($Credential) {
    $ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Credential.UserName, $Credential.Password)
  } else {
    throw "No PSCredential provided. For MFA-only tenants, use the App-only variant (see script notes)."
  }
  return $ctx
}

function Get-SiteCategory {
  param([string]$Template,[string]$Url)
  if ($Template -eq 'SPSPERS#10' -or $Url -like '*-my.sharepoint.com/personal/*') { return 'OneDrive' }
  elseif ($Template -eq 'TEAMCHANNEL#0') { return 'TeamsPrivateChannel' }
  elseif ($Template -eq 'GROUP#0') { return 'GroupConnectedTeamSite' }
  else { return 'SharePointSite' }
}

function Is-TargetPrincipal {
  param([string]$Login,[switch]$IncludeEveryone)
  if ([string]::IsNullOrWhiteSpace($Login)) { return $false }
  $ln = $Login.ToLowerInvariant()
  if ($ln.StartsWith($EEEUPrefix)) { return $true }
  if ($IncludeEveryone -and $ln -eq $EveryoneVal) { return $true }
  return $false
}

function Add-Result {
  param(
    [System.Collections.Generic.List[object]]$Bag,
    [hashtable]$Data
  )
  $Bag.Add([pscustomobject]$Data) | Out-Null
}

# Returns hashtable with headers for REST (either cookie or bearer)
function Get-AuthHeadersForSite {
  param([string]$SiteUrl,[Microsoft.SharePoint.Client.SharePointOnlineCredentials]$SpCred,[string]$Bearer)
  $headers = @{ 'Accept'='application/json;odata=nometadata' }
  if ($SpCred) {
    $cookie = $SpCred.GetAuthenticationCookie($SiteUrl)
    $headers['Cookie'] = $cookie
    # RequestDigest is not needed for GETs; we only GET list items here
  } elseif ($Bearer) {
    $headers['Authorization'] = "Bearer $Bearer"
  }
  return $headers
}

function Get-ItemsWithUniquePerms {
  param(
    [string]$SiteUrl,
    [Guid]$ListId,
    [Microsoft.SharePoint.Client.SharePointOnlineCredentials]$SpCred,
    [string]$Bearer
  )
  $headers = Get-AuthHeadersForSite -SiteUrl $SiteUrl -SpCred $SpCred -Bearer $Bearer
  $items = @()
  $base = "$SiteUrl/_api/web/lists(guid'$ListId')/items?`$select=Id,HasUniqueRoleAssignments,FileRef,FSObjType&`$top=5000"
  $next = $base
  while ($next) {
    try {
      $resp = Invoke-RestMethod -Uri $next -Headers $headers -Method Get
    } catch {
      Write-Warning "REST failed on $SiteUrl list $ListId: $($_.Exception.Message)"
      break
    }
    $batch = @($resp.value | Where-Object { $_.HasUniqueRoleAssignments -eq $true })
    $items += $batch
    $next = $null
    if ($resp.'@odata.nextLink') { $next = $resp.'@odata.nextLink' }
  }
  return $items
}
#endregion
#region --- main ---
$ErrorActionPreference = 'Stop'
Ensure-CSOM
Connect-Admin

$results = New-Object System.Collections.Generic.List[object]

$sites = Get-TenantSites -IncludeOneDrive:$IncludeOneDrive
if ($SiteUrlFilter) {
  $sites = $sites | Where-Object { $_.Url -like $SiteUrlFilter }
}
Write-Host ("Sites to scan: {0}" -f ($sites | Measure-Object).Count)

$index = 0
foreach ($site in $sites) {
  $index++
  Write-Progress -Activity "Scanning sites" -Status $site.Url -PercentComplete (($index/$($sites.Count))*100)

  $siteTemplate = $site.Template
  $siteCategory = Get-SiteCategory -Template $siteTemplate -Url $site.Url
  $groupId = $null; if ($site.PSObject.Properties.Name -contains 'GroupId') { $groupId = $site.GroupId }

  # Create CSOM context
  try {
    $ctx = New-ClientContext -Url $site.Url -Credential $Credential
  } catch {
    Write-Warning "Skipping $($site.Url) - CSOM connect failed: $($_.Exception.Message)"
    continue
  }

  # --- Web scope ---
  try {
    $web = $ctx.Web
    $ctx.Load($web, "Title","Url","HasUniqueRoleAssignments","RoleAssignments")
    $ctx.ExecuteQuery()
    # Batch load Members and RoleDefinitionBindings for web role assignments
    foreach ($ra in $web.RoleAssignments) {
      $ctx.Load($ra.Member)
      $ctx.Load($ra.RoleDefinitionBindings)
    }
    $ctx.ExecuteQuery()
    foreach ($ra in $web.RoleAssignments) {
      $memberLogin = $ra.Member.LoginName
      if (Is-TargetPrincipal -Login $memberLogin -IncludeEveryone:$IncludeEveryone) {
        $roles = ($ra.RoleDefinitionBindings | ForEach-Object Name) -join '; '
        Add-Result -Bag $results -Data @{
          FoundOn            = 'Web'
          SiteCategory       = $siteCategory
          SiteTemplate       = $siteTemplate
          GroupId            = $groupId
          SiteUrl            = $site.Url
          WebUrl             = $web.Url
          ListTitle          = $null
          ObjectUrl          = $web.Url
          PrincipalTitle     = $ra.Member.Title
          PrincipalLoginName = $memberLogin
          Roles              = $roles
          Inherited          = (-not $web.HasUniqueRoleAssignments)
        }
      }
    }
  } catch {
    Write-Warning "Web scope failed on $($site.Url): $($_.Exception.Message)"
  }

  # --- List scope (only lists with unique perms) ---
  try {
    $ctx.Load($web.Lists)
    $ctx.ExecuteQuery()
    foreach ($list in $web.Lists) {
      $ctx.Load($list, "Title","Id","DefaultViewUrl","HasUniqueRoleAssignments","RoleAssignments")
      $ctx.ExecuteQuery()
      if (-not $list.HasUniqueRoleAssignments) { 
        # Optional: you can still check inherited if you want web-level grants to flow, but we only report explicit EEEU
        continue 
      }
      foreach ($ra in $list.RoleAssignments) {
        $ctx.Load($ra.Member)
        $ctx.Load($ra.RoleDefinitionBindings)
      }
      $ctx.ExecuteQuery()
      foreach ($ra in $list.RoleAssignments) {
        $memberLogin = $ra.Member.LoginName
        if (Is-TargetPrincipal -Login $memberLogin -IncludeEveryone:$IncludeEveryone) {
          $roles = ($ra.RoleDefinitionBindings | ForEach-Object Name) -join '; '
          $listUrl = ($site.Url.TrimEnd('/') + '/' + $list.DefaultViewUrl.TrimStart('/'))
          Add-Result -Bag $results -Data @{
            FoundOn            = 'List'
            SiteCategory       = $siteCategory
            SiteTemplate       = $siteTemplate
            GroupId            = $groupId
            SiteUrl            = $site.Url
            WebUrl             = $web.Url
            ListTitle          = $list.Title
            ObjectUrl          = $listUrl
            PrincipalTitle     = $ra.Member.Title
            PrincipalLoginName = $memberLogin
            Roles              = $roles
            Inherited          = $false
          }
        }
      }

      # --- Item/Folder/File scope (optional) ---
      if ($Deep) {
        # Use REST to find items with unique perms; then use CSOM to read their role assignments
        $spCred = $ctx.Credentials -as [Microsoft.SharePoint.Client.SharePointOnlineCredentials]
        $uniq = Get-ItemsWithUniquePerms -SiteUrl $web.Url -ListId $list.Id -SpCred $spCred
        foreach ($i in $uniq) {
          try {
            $li = $list.GetItemById([int]$i.Id)
            $ctx.Load($li)
            $ctx.Load($li.RoleAssignments)
            $ctx.ExecuteQuery()
            foreach ($ra in $li.RoleAssignments) {
              $ctx.Load($ra.Member)
              $ctx.Load($ra.RoleDefinitionBindings)
            }
            $ctx.ExecuteQuery()
            foreach ($ra in $li.RoleAssignments) {
              $memberLogin = $ra.Member.LoginName
              if (Is-TargetPrincipal -Login $memberLogin -IncludeEveryone:$IncludeEveryone) {
                $roles = ($ra.RoleDefinitionBindings | ForEach-Object Name) -join '; '
                $kind  = if ($i.FSObjType -eq 0) { 'Item' } elseif ($i.FSObjType -eq 1) { 'Folder' } else { 'File' }
                $objUrl = if ($i.FileRef) { "$($site.Url.TrimEnd('/'))$($i.FileRef)" } else { $list.DefaultViewUrl }
                Add-Result -Bag $results -Data @{
                  FoundOn            = $kind
                  SiteCategory       = $siteCategory
                  SiteTemplate       = $siteTemplate
                  GroupId            = $groupId
                  SiteUrl            = $site.Url
                  WebUrl             = $web.Url
                  ListTitle          = $list.Title
                  ObjectUrl          = $objUrl
                  PrincipalTitle     = $ra.Member.Title
                  PrincipalLoginName = $memberLogin
                  Roles              = $roles
                  Inherited          = $false
                }
              }
            }
          } catch {
            Write-Warning "Item-level load failed (List '$($list.Title)' ID $($i.Id)) on $($site.Url): $($_.Exception.Message)"
          }
        }
      } # end Deep
    } # end foreach list
  } catch {
    Write-Warning "List scope failed on $($site.Url): $($_.Exception.Message)"
  }
} # end foreach site

# --- Output ---
$results | Sort-Object SiteUrl, WebUrl, ListTitle, FoundOn |
  Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8

Write-Host "Done. Results saved to: $OutputCsv"
#endregion